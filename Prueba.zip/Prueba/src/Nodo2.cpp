/*
 * Nodo2.cpp
 *
 *  Created on: 18/10/2017
 *      Author: Sara
 */

#include "Nodo2.h"
#include <iostream>

Nodo2::Nodo2 (int dato){
	this->dato = dato;
	head = NULL;
	tail = NULL;
}
Nodo2::~Nodo2(){

}
