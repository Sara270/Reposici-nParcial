/*
 * Nodo.cpp
 *
 *  Created on: 18/10/2017
 *      Author: Sara
 */

#include "Nodo.h"

Node_::Node_ (int dato){
	this->dato = dato;
	siguiente = NULL;
}
Node_::~Node_(){

}
