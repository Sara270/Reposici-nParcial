/*
 * Nodo1.h
 *
 *  Created on: 19/10/2017
 *      Author: Sara
 */

#ifndef NODO1_H_
#define NODO1_H_
#include <string>

class Nodo1 {
public:
	Nodo1 (int dato);
    ~Nodo1 ();
	int dato;
	Nodo1 *siguiente;

};

#endif /* NODO1_H_ */
