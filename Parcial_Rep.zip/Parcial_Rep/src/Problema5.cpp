/*
 * Problema5.cpp
 *
 *  Created on: 19/10/2017
 *      Author: Sara
 */
#include "ListaEnlazada.h"
#include "Problema5.h"

ListaEnlazada* ganadores;


Problema5 :: Problema5 (){

	}

Problema5 :: ~Problema5(){

}
