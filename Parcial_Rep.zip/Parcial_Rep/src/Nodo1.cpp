/*
 * Nodo1.cpp
 *
 *  Created on: 19/10/2017
 *      Author: Sara
 */

#include "Nodo1.h"
#include <iostream>
#include <string>

//Clase Nodo

Nodo1 :: Nodo1 (int dato){
	this->dato = dato;
	siguiente = NULL;
}
Nodo1 :: ~Nodo1(){

}
