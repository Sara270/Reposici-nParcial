/*
 * Problema5.h
 *
 *  Created on: 19/10/2017
 *      Author: Sara
 */

#ifndef PROBLEMA5_H_
#define PROBLEMA5_H_
#include "ListaEnlazada.h"

class Problema5 {
public:
	Problema5 ();
	    ~Problema5 ();
};

#endif /* PROBLEMA5_H_ */
